class Conv(Op):
    def __init__(self, input, nfilters, window=5, stride=1):
        shp = input.shape
        w = Param.randn((nfilters, window, window, shp[3]))
        b = Param.zeros((nfilters))
        self._input = [input, w, b]
        self._window = window
        self._nfilters = nfilters
        self._stride = stride
        self._value = np.empty((shp[0], shp[1], shp[2], nfilters), dtype=DTYPE)
        self._gradient = np.zeros(self._value.shape, dtype=DTYPE)

    def forward(self):
        n = self._input[0].shape[0]
        shp = self.shape

        # Reshape images to (count, channels, height, width), then apply im2col
        im = self._input[0]._value.transpose((0, 3, 1, 2))
        self._col = im2col(im, self._window, self._window, (self._window - 1) / 2, self._stride)

        # Now that all the windows are in matrix form, calculate w.dot(col) + b
        w = self._input[1]._value.reshape(self._nfilters, -1)
        b = self._input[2]._value.reshape(-1, 1)
        self._value = np.dot(w, self._col) + b

        # Reshape result from (nfilters, -1) to (count, height, width, nfilters)
        self._value = self._value.reshape(shp[3], n, shp[1], shp[2]).transpose((1, 2, 3, 0))
        self._gradient = np.zeros(self._value.shape, dtype=DTYPE)

    def backward(self):
        # Reshape gradient to (nfilters, -1) and back-propagate through the dot product
        gradient = self._gradient.transpose((3, 0, 1, 2)).reshape(self._nfilters, -1)
        self._input[1]._gradient += gradient.dot(self._col.T).reshape(self._input[1]._gradient.shape)
        self._input[2]._gradient += gradient.sum(axis=1)

        # The gradient w.r.t the images is similar, but we need to aggregate the results over the windows
        w = self._input[1]._value.reshape(self._nfilters, -1)
        shp = self._input[0].shape
        imgradient = col2im(w.T.dot(gradient), shp[0], shp[3], shp[1], shp[2], self._window, self._window,
                            (self._window - 1) / 2, self._stride)

        # Reshape the result back to (count, height, width, channels)
        self._input[0]._gradient += imgradient.transpose((0, 2, 3, 1))


class Pool(Op):
    def __init__(self, input, window=2, stride=2):
        shp = input.shape
        self._input = [input]
        self._window = window
        self._stride = stride
        self._value = np.empty((shp[0], (shp[1] - window) / stride + 1, (shp[2] - window) / stride + 1, shp[3]),
                               dtype=DTYPE)
        self._gradient = np.zeros(self._value.shape, dtype=DTYPE)

    def forward(self):
        n = self._input[0].shape[0]
        shp = self.shape

        # Reshape images to (count, channels, height, width), then apply im2col
        im = self._input[0]._value.transpose((0, 3, 1, 2))
        col = im2col(im, self._window, self._window, 0, self._stride)
        col = col.reshape(self._window * self._window, im.shape[1], -1).transpose((1, 2, 0))

        # Find the maximum in every window and store its index using a mask
        self._mask = col.argmax(axis=2)
        self._mask = (self._mask[:, :, np.newaxis] == np.arange(self._window * self._window))
        self._value = col[self._mask].reshape(shp[3], n, shp[1], shp[2]).transpose((1, 2, 3, 0))
        self._gradient = np.zeros(self._value.shape, dtype=DTYPE)

    def backward(self):
        shp = self._input[0].shape

        # The gradient is calculate using the mask indices then aggregated over the windows
        gradient = self._gradient.transpose((3, 0, 1, 2)).reshape(1, shp[3], -1)
        col = (self._mask.transpose((2, 0, 1)) * gradient).reshape(-1, gradient.shape[2])
        imgradient = col2im(col, shp[0], shp[3], shp[1], shp[2], self._window, self._window, 0, self._stride)

        # Reshape the result back to (count, height, width, channels)
        self._input[0]._gradient += imgradient.transpose((0, 2, 3, 1))

