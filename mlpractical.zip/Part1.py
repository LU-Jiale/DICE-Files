from mlp.train_and_plot import train_model_and_plot_stats
import numpy as np
import logging
from mlp.data_providers import MNISTDataProvider, EMNISTDataProvider

# The below code will set up the data providers, random number
# generator and logger objects needed for training runs. As
# loading the data from file take a little while you generally
# will probably not want to reload the data providers on
# every training run. If you wish to reset their state you
# should instead use the .reset() method of the data providers.

# Seed a random number generator
seed = 10102016
rng = np.random.RandomState(seed)
batch_size = 100
# Set up a logger object to print info about the training run to stdout
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.handlers = [logging.StreamHandler()]

# Create data provider objects for the MNIST data set
train_data = EMNISTDataProvider('train', batch_size=batch_size, rng=rng)
valid_data = EMNISTDataProvider('valid', batch_size=batch_size, rng=rng)



# DNN
from mlp.layers import AffineLayer, SoftmaxLayer, SigmoidLayer, ReluLayer, LeakyReluLayer, ELULayer, SELULayer
from mlp.errors import CrossEntropySoftmaxError
from mlp.models import MultipleLayerModel
from mlp.initialisers import ConstantInit, GlorotUniformInit
from mlp.learning_rules import AdamLearningRule
from mlp.optimisers import Optimiser

def setupModel(input_dim, hidden_dim, output_dim, weights_init, biases_init, hiddenLayers = 2):
    train_data.reset()
    valid_data.reset()
    layerList = [AffineLayer(input_dim, hidden_dim, weights_init, biases_init), ELULayer()]
    while(hiddenLayers > 1):
        layerList += [AffineLayer(hidden_dim, hidden_dim, weights_init, biases_init), ELULayer()]
        hiddenLayers -= 1
    layerList += [AffineLayer(hidden_dim, output_dim, weights_init, biases_init)]
    return MultipleLayerModel(layerList)

#setup hyperparameters
learning_rate = 0.05
num_epochs = 5
stats_interval = 1
input_dim, output_dim, hidden_dim = 784, 47, 100


error = CrossEntropySoftmaxError()
# Use a basic gradient descent learning rule
learning_rule = GradientDescentLearningRule(learning_rate=learning_rate)
feedback = {}
layerList = [4]
for index in layerList:
    rng = np.random.RandomState(seed)
    weights_init = GlorotUniformInit(rng=rng)
    biases_init = ConstantInit(0.)
    model = setupModel(input_dim, hidden_dim, output_dim, weights_init, biases_init, hiddenLayers = index)
    #Remember to use notebook=False when you write a script to be run in a terminal
    feedback[index] = train_model_and_plot_stats(
        model, error, learning_rule, train_data, valid_data, num_epochs,
        stats_interval, notebook=True, picName = str(index) +"Layers")