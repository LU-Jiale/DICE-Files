import numpy as np
import time
from mlp.layers import ConvolutionalLayer, MaxPoolingLayer

batch_size = 8
num_input_channels = 3
input_dim_1 = 6
input_dim_2 = 6
kernel_dim_1 = 2
kernel_dim_2 = 2

inputs = np.arange(batch_size*num_input_channels*input_dim_1*input_dim_2).\
    reshape(batch_size, num_input_channels, input_dim_1, input_dim_2)
layer1 = MaxPoolingLayer(batch_size, num_input_channels,
                 input_dim_1, input_dim_2,
                 kernel_dim_1, kernel_dim_2)

start = time.clock()
for i in range(1000):
    f = layer1.fprop(inputs)
    b = layer1.bprop(inputs, 1,np.ones([batch_size, num_input_channels, input_dim_1/kernel_dim_1, input_dim_2/kernel_dim_2]))
end = time.clock()
print end-start
# print layer1.kernels